package com.eric.signinprojectca.models.user

data class UserDataModel(
    val userName: String,
    val userAge: String,
    val userEmail: String,
    val userPassword: String

)
