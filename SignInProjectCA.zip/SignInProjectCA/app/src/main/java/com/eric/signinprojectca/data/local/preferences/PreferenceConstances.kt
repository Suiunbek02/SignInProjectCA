package com.eric.signinprojectca.data.local.preferences

object PreferenceConstances {

    const val USER_NAME = "user_name"
    const val USER_AGE = "user_age"
    const val USER_EMAIL = "user_email"
    const val USER_PASSWORD = "user_password"
}